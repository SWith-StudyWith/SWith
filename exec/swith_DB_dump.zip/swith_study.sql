CREATE DATABASE  IF NOT EXISTS `swith` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `swith`;
-- MySQL dump 10.13  Distrib 5.7.35, for Win64 (x86_64)
--
-- Host: i6a501.p.ssafy.io    Database: swith
-- ------------------------------------------------------
-- Server version	5.7.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `study`
--

DROP TABLE IF EXISTS `study`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `study` (
  `study_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `goal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_used` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`study_id`),
  KEY `FKf561xlrfo0qtpl3vwkxiw4cs8` (`member_id`),
  CONSTRAINT `FKf561xlrfo0qtpl3vwkxiw4cs8` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `study`
--

LOCK TABLES `study` WRITE;
/*!40000 ALTER TABLE `study` DISABLE KEYS */;
INSERT INTO `study` VALUES (1,'yj8U4jnIC1GeyXk5oU0nBsn7j1WfgWsL','백준 플래티넘이 목표',NULL,'N','알고리즘 스터디',NULL),(2,'VpNcEAtPax0o5Wt6RcbwmIunrcCLzrwg','OPic AL',NULL,'N','영어회화 스터디',NULL),(6,'q2EEMXTI94SYY7pWFUFYrAwfftJ3eV3j','공통프로젝트 최수우상','https://firebasestorage.googleapis.com/v0/b/swith-23ba9.appspot.com/o/study_image%2F7d40d2b6-064d-49cc-b7b7-320dbb8365f4_1645066934033?alt=media','N','달달한 쌍화차',8),(8,'g0GtKTjLDeNeM9PLnxeIgkk6MX2qkB1K','공통 프로젝트',NULL,'N','서울 5반 스터디',NULL),(9,'BzFu6iowWKqy2HN0wSKuAdIXWn0KxaOM','1일 1문제씩, 알고리즘 마스터 하기','https://firebasestorage.googleapis.com/v0/b/swith-23ba9.appspot.com/o/study_image%2F845f3297-96d8-48d5-ba33-d84bf7523ed1_1645089101468?alt=media','N','1일 1문제 알고리즘 스터디',NULL);
/*!40000 ALTER TABLE `study` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 21:35:15
