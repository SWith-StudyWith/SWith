CREATE DATABASE  IF NOT EXISTS `swith` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `swith`;
-- MySQL dump 10.13  Distrib 5.7.35, for Win64 (x86_64)
--
-- Host: i6a501.p.ssafy.io    Database: swith
-- ------------------------------------------------------
-- Server version	5.7.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `chat`
--

DROP TABLE IF EXISTS `chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat` (
  `chat_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  `study_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`chat_id`),
  KEY `FKgvc5hrt0h18xk63qosss3ti30` (`member_id`),
  KEY `FK9lh9y21bfifn8kh4tg43lkak7` (`study_id`),
  CONSTRAINT `FK9lh9y21bfifn8kh4tg43lkak7` FOREIGN KEY (`study_id`) REFERENCES `study` (`study_id`),
  CONSTRAINT `FKgvc5hrt0h18xk63qosss3ti30` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat`
--

LOCK TABLES `chat` WRITE;
/*!40000 ALTER TABLE `chat` DISABLE KEYS */;
INSERT INTO `chat` VALUES (1,'안녕하세요!','2022-02-17 11:56:34.911000',4,6),(2,'gk-dl','2022-02-17 11:56:42.427000',1,6),(3,'스윗~','2022-02-17 11:56:48.812000',4,6),(4,'안녕하세요','2022-02-17 13:54:38.016000',7,6),(5,'잘 보이시나요?','2022-02-17 13:54:41.179000',7,6),(6,'dkfjlkfjsdf','2022-02-17 13:54:49.454000',9,6),(7,'오늘 문제 뭐 푸나요?','2022-02-17 14:13:51.850000',7,6),(8,'하이하이','2022-02-17 14:20:09.761000',12,6),(9,'저 아직 있어요','2022-02-17 14:46:42.106000',12,6),(10,'근데','2022-02-17 14:46:45.857000',12,6),(11,'저','2022-02-17 14:46:48.577000',12,6),(12,'왜 제 원래 계정 사라졌나요','2022-02-17 14:47:01.973000',12,6),(13,'네 빨리 들어올 수 있어요','2022-02-17 14:59:38.186000',12,6),(14,'제가 그렇거든요','2022-02-17 14:59:42.190000',12,6),(15,'https://i6a501.p.ssafy.io/','2022-02-17 15:51:45.983000',7,6),(16,'저,,,화면 공유 취소가 안됩니다...','2022-02-17 15:55:03.521000',3,6),(17,'여러명이 공유했다가 끄면 문제가 발생하나봐요','2022-02-17 15:55:28.050000',3,6),(18,'https://i6a501.p.ssafy.io/','2022-02-17 16:10:34.689000',7,6),(19,'5반 여러분','2022-02-17 20:41:07.167000',7,6),(20,'수고 많으셨어요~','2022-02-17 20:41:11.509000',7,6),(21,'화잍ㅇ','2022-02-17 20:41:12.991000',7,6),(22,'화이팅','2022-02-17 20:41:15.694000',7,6),(23,'ㅎㅇㅌ','2022-02-17 20:41:17.302000',3,6);
/*!40000 ALTER TABLE `chat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 21:35:15
