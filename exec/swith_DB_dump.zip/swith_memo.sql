CREATE DATABASE  IF NOT EXISTS `swith` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `swith`;
-- MySQL dump 10.13  Distrib 5.7.35, for Win64 (x86_64)
--
-- Host: i6a501.p.ssafy.io    Database: swith
-- ------------------------------------------------------
-- Server version	5.7.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `memo`
--

DROP TABLE IF EXISTS `memo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `memo` (
  `memo_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `color` bigint(20) DEFAULT NULL,
  `content` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transform` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  `study_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`memo_id`),
  KEY `FK5qolu1o1dg88dow8h0o9rsi9y` (`member_id`),
  KEY `FKlkbw67alpp5mp90s1jcai7a00` (`study_id`),
  CONSTRAINT `FK5qolu1o1dg88dow8h0o9rsi9y` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FKlkbw67alpp5mp90s1jcai7a00` FOREIGN KEY (`study_id`) REFERENCES `study` (`study_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memo`
--

LOCK TABLES `memo` WRITE;
/*!40000 ALTER TABLE `memo` DISABLE KEYS */;
INSERT INTO `memo` VALUES (1,1,'sdfsfdfsdf','matrix(1, 0, 0, 1, 0, 0) translate(447px, 197px) rotate(32.2004deg)',1,6),(2,2,'dfsdfdfsfddfsdfdf','matrix(1, 0, 0, 1, 0, 0) translate(398px, 197px) rotate(-24.589deg)',9,6),(6,1,'히히','matrix(1, 0, 0, 1, 0, 0) translate(445px, 126px) rotate(362.122deg)',4,6),(7,0,'두 개','matrix(1, 0, 0, 1, 0, 0) translate(654.5px, 113px) scale(0.754808, 0.673077)',4,6),(8,0,'','matrix(1, 0, 0, 1, 0, 0) translate(676.5px, 143.5px) rotate(-18.3784deg) scale(1.1549, 1.17651)',3,6),(9,1,'색깔도 바뀌는군요!','matrix(1, 0, 0, 1, 0, 0) translate(513px, 116px)',3,6),(10,2,'하이하이ㄴㅇㄹㄴㅇㄹ','matrix(1, 0, 0, 1, 0, 0) translate(368px, 121px) rotate(-18.7765deg)',11,6),(11,1,'안녕','matrix(1, 0, 0, 1, 0, 0) translate(695px, 222px) rotate(-11.2061deg)',11,6),(12,0,'','matrix(1, 0, 0, 1, 0, 0) translate(89px, 129px)',11,6),(14,0,'Test','matrix(1, 0, 0, 1, 0, 0) translate(286px, 81px)',7,6),(15,1,'하이하이','matrix(1, 0, 0, 1, 0, 0) translate(404px, 118px) rotate(2.07922deg)',14,6),(16,2,'서울 5반 여러분 모두 고생하셨습니다~!\n','matrix(1, 0, 0, 1, 0, 0) translate(701px, 126px) rotate(17.8756deg)',14,6);
/*!40000 ALTER TABLE `memo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 21:35:14
