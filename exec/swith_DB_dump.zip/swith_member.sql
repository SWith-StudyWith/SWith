CREATE DATABASE  IF NOT EXISTS `swith` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;
USE `swith`;
-- MySQL dump 10.13  Distrib 5.7.35, for Win64 (x86_64)
--
-- Host: i6a501.p.ssafy.io    Database: swith
-- ------------------------------------------------------
-- Server version	5.7.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `member_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `goal` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_deleted` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kakao_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nickname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'2022-02-17 11:32:09.739000','g2hhh2ee@gmail.com','쌍절곤 좀팡공이 ?','g2hhh2ee@gmail.com','https://firebasestorage.googleapis.com/v0/b/swith-23ba9.appspot.com/o/profile_image%2Ff0a7df20-3e12-4681-a074-91c9d8e2d435_1645095691741?alt=media','N',NULL,'한찌리버드','$2a$10$v2aTI3M1ucTlHQeugXrvAew3z.pot1MeopWcXdxg2k5t1tLpRkLg.','MEMBER','2022-02-17 20:01:32.166000'),(2,'2022-02-17 11:32:53.000000','ssafy@ssafy.com','',NULL,NULL,'N',NULL,'test_ssafy','$2a$10$/2dH3huoobePVYrb.DjdrexFPg.9KndY0ZaytVSv3cIX4fNRZ8LhW','MEMBER','2022-02-17 12:37:58.418000'),(3,'2022-02-17 11:46:37.497000','seongjaee12@gmail.com',NULL,'seongjaee12@gmail.com',NULL,'N',NULL,'이성재','$2a$10$7SrZdd52Uy6j4SZgrH29se6va6i8TKH/88.tl2Do/frbOaFiwgoSi','MEMBER','2022-02-17 11:46:37.497000'),(4,'2022-02-17 11:50:45.007000','official.swith@gmail.com','','official.swith@gmail.com','https://firebasestorage.googleapis.com/v0/b/swith-23ba9.appspot.com/o/profile_image%2F5537d39c-55f1-4163-a611-0773063741f2_1645094975893?alt=media','N',NULL,'swith','$2a$10$.hLhIhJwsR3MecTLwO7sOeApGgD8KfOCjetT6mfY6f1TdPRh7FMCa','MEMBER','2022-02-17 19:50:40.731000'),(5,'2022-02-17 12:43:18.673000','mstkang@gmail.com',NULL,'mstkang@gmail.com',NULL,'N',NULL,'강시몬','$2a$10$4tNwUsC/0qlXKXmupaeCf.Qg4Fv.5gY.X1OUyifwAtH6sk0nfDtF2','MEMBER','2022-02-17 12:43:18.673000'),(7,'2022-02-17 13:40:18.262000','lovesu5632@gmail.com','','lovesu5632@gmail.com',NULL,'N',NULL,'멋쟁이 한라봉','$2a$10$4N3ycdKlZ73SM3YJfg1B/.AzC5xcOv2dxJfWb5iwbZCs/bwJ4nxVW','MEMBER','2022-02-17 19:50:37.480000'),(8,'2022-02-17 13:44:03.489000','kdh1234@ssafy.com','',NULL,'https://firebasestorage.googleapis.com/v0/b/swith-23ba9.appspot.com/o/profile_image%2F4293a854-02f1-41b6-b2db-f7cf4d3ca175_1645078305973?alt=media','N',NULL,'김도현','$2a$10$zJuWzddpNatchDhDWaNMx.bzSGwOesXzY2/3l9R3KOXRF2s8P8KjK','MEMBER','2022-02-17 15:11:46.521000'),(9,'2022-02-17 13:51:19.795000','aprilabove22@gmail.com',NULL,'aprilabove22@gmail.com',NULL,'Y',NULL,'찌리뿡','$2a$10$kgJABMZJBfyTZsNhwBreeugjZl70OHmo1QIw2BKIuNNe1jD1z17M.','MEMBER','2022-02-17 14:02:43.258000'),(10,'2022-02-17 13:52:07.843000','zummy0130@gmail.com',NULL,'zummy0130@gmail.com',NULL,'N',NULL,'박주미','$2a$10$Co/JufdFf21bujV16rZVcuu6MaG.mCUKgKHOg1ancLw8UqcX.xy6e','MEMBER','2022-02-17 13:52:07.843000'),(11,'2022-02-17 14:11:34.614000','aprilabove22@gmail.com',NULL,'aprilabove22@gmail.com',NULL,'Y',NULL,'찌리뿡','$2a$10$FINRA8MpBrxTRvY0RaHnaeBz.ZfNRwnmE0C.ylqd6QawC9.h08kNe','MEMBER','2022-02-17 16:01:53.241000'),(12,'2022-02-17 14:19:01.329000','sang712h@gmail.com',NULL,'sang712h@gmail.com',NULL,'N',NULL,'Sanggil Han','$2a$10$f7jkndX7gxHPabh/n/grdep2E29S4F.fyvAUpArwahYoQSWWWp9PW','MEMBER','2022-02-17 14:19:01.329000'),(13,'2022-02-17 14:45:21.874000','labyrinthird@gmail.com',NULL,NULL,NULL,'N','2081685444','이성재','$2a$10$.qCzBowxSK6d57mTzHYswupqLpo8ICWt9XiXwQ1mLUDJVTd0MUCwa','MEMBER','2022-02-17 14:45:21.874000'),(14,'2022-02-17 16:08:22.293000','aprilabove22@gmail.com',NULL,'aprilabove22@gmail.com',NULL,'N',NULL,'찌리뿡','$2a$10$fBCMvv.gQIn5.3JZTN5zLuCl5BURF6UyHHD2CbPX3.o8MwB7riiWe','MEMBER','2022-02-17 16:08:22.293000'),(15,'2022-02-17 17:35:00.424000','test.consultant@ssafy.com',NULL,NULL,NULL,'N',NULL,'컨설턴트','$2a$10$9e0rAEaCHD0PRZ.ECzmUMOFLbPzGoqTzwXrL.LqMqR/GGId6D0oKK','MEMBER','2022-02-17 17:35:00.424000'),(16,'2022-02-17 17:35:50.617000','test.coach@ssafy.com',NULL,NULL,NULL,'N',NULL,'실습코치','$2a$10$qPlYozN3sjn4WPZc3YOv/eNXh.j6Btm7.aTxTV9Z9BEWpSOLSNVNS','MEMBER','2022-02-17 17:35:50.617000'),(17,'2022-02-17 18:00:18.345000','kdh494849@gmail.com',NULL,'kdh494849@gmail.com',NULL,'N',NULL,'김도현','$2a$10$CZtfWW0NmhwnbyTz2/d1OuE03Wyu5IiGc1Hyt..LorhyTt18JkUcK','MEMBER','2022-02-17 18:00:18.345000'),(18,'2022-02-17 18:02:23.557000','kdh494849@gmail.com',NULL,NULL,NULL,'N',NULL,'김도커','$2a$10$54WVTCqKMxDZhjJqVRKRCurYNDbykvZ7iahYMLp1VJ32qNmilBuQC','MEMBER','2022-02-17 18:02:23.557000'),(19,'2022-02-17 19:08:52.559000','test@ssafy.com',NULL,NULL,NULL,'N',NULL,'ssafy','$2a$10$HRrSku/g0BI3Oc/Ypv72Tu877YAbyASRyPSA1hslIr3zfr2s0A9xK','MEMBER','2022-02-17 19:08:52.559000'),(20,'2022-02-17 19:25:39.900569','seongjaee12@gmail.com',NULL,NULL,NULL,'N',NULL,'이성재','$2a$10$K7Sxx7L3DFYwBMANcDKNUO/nyHK0uQ9gpVOvh4arQH8K8gnpe4RrG','MEMBER','2022-02-17 19:25:39.900569'),(21,'2022-02-17 19:52:12.943000','g2hhh2ee@gmail.com','? 오늘 시간 비어요',NULL,'https://firebasestorage.googleapis.com/v0/b/swith-23ba9.appspot.com/o/profile_image%2Fd22ab795-8e72-44c9-9a8e-87b9a993d85c_1645095722813?alt=media','N',NULL,'옆자리신사분 ','$2a$10$7OOlLmLoHDKmLtWuzEfml.5RcnM0VpOopq9FhBxNnOGxesva9Kjqy','MEMBER','2022-02-17 20:02:03.208000');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 21:35:14
